package com.smbms.dao.role;

import com.smbms.dao.baseDao;
import com.smbms.entity.role;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class roledaoimp implements roledao{

    public List<role> getrolelist(Connection connection) throws SQLException {

            ArrayList<role> list = new ArrayList<role>();
            PreparedStatement preparedStatement = null;
            ResultSet rs = null;
            String sql = "select  *  from smbms_role r ";

            if (connection != null) {
                Object[] params = {};
                rs = baseDao.execute(connection, sql, params, preparedStatement);
                while (rs.next()) {
                    role role = new role();
                    role.setId(rs.getInt("id"));
                    role.setRoleCode(rs.getString("roleCode"));
                    role.setRoleName(rs.getString("roleName"));
                    list.add(role);
                }
            }
            baseDao.close(connection, preparedStatement, null);

            return list;
        }

}
