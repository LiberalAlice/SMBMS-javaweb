package com.smbms.dao.user;

import com.smbms.dao.baseDao;
import com.smbms.entity.User;
import org.junit.jupiter.api.Test;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDaoImp implements UserDao {

    public User getLoginUser(Connection connection, String userCode) throws SQLException {
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        User user = null;
        String sql = "select * from smbms_user where userCode = ?";
        Object[] param = {userCode};

        rs = baseDao.execute(connection, sql, param, preparedStatement);

        if (rs.next()) {
            user = new User();
            user.setId(rs.getInt("id"));
            user.setUserCode(rs.getString("userCode"));
            user.setUserName(rs.getString("userName"));
            user.setUserPassword(rs.getString("userPassword"));
            user.setGender(rs.getInt("gender"));
            user.setBirthday(rs.getDate("birthday"));
            user.setPhone(rs.getString("phone"));
            user.setAddress(rs.getString("address"));
            user.setUserRole(rs.getInt("userRole"));
            user.setCreatedBy(rs.getInt("createdBy"));
            user.setCreationDate(rs.getTimestamp("creationDate"));
            user.setModifyBy(rs.getInt("modifyBy"));
            user.setModifyDate(rs.getTimestamp("modifyDate"));
            baseDao.close(null, preparedStatement, rs);
        }

        return user;
    }

    public boolean pwModify(Connection connection, int id, String password) throws SQLException {
        boolean flag = false;
        PreparedStatement preparedStatement = null;

        String sql = "update smbms_user set userPassword = ? where id = ?";
        int row = 0;
        Object[] param = {password, id};
        if (connection != null) {
            row = baseDao.execute2(connection, sql, param, preparedStatement);
            if (row > 0) {
                flag = true;
            }

        }
        baseDao.close(connection, preparedStatement, null);

        return flag;
    }

    public int getCount(Connection connection, String userName, int userRole) throws SQLException {
        int count = 0;
        ArrayList<Object> list = new ArrayList<Object>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String sql = "select  count(1) as count from smbms_user u ,smbms_role r where  u.userRole = r.id";
        StringBuffer sb = new StringBuffer(sql);
        if (connection != null) {
            if (userName != null) {    //!StringUtils.isNullOrEmpty(userName)
                sb.append(" and u.userName like ?");
                list.add("%" + userName + "%");
            }
            if (userRole > 0) {
                sb.append(" and  u.userRole = ?");
                list.add(userRole);
            }
            Object[] params = list.toArray();
//            System.out.println(sb);
            resultSet = baseDao.execute(connection, sb.toString(), params, preparedStatement);
            if (resultSet.next()) {
                count = resultSet.getInt("count");
            }
        }
        baseDao.close(connection, preparedStatement, null);
        return count;
    }

    public List<User> getUserlist(Connection connection, String userName, int userRole, int currentPage, int pagesize) throws SQLException {

        List<User> userList = new ArrayList<User>();

        ArrayList<Object> list = new ArrayList<Object>();
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        String sql = "select u.* ,r.roleName as userRoleName from smbms_user u,smbms_role r where u.userRole = r.id";

        StringBuffer sb = new StringBuffer(sql);
        if (connection != null) {
            if (userName != null) {    //!StringUtils.isNullOrEmpty(userName)
                sb.append(" and u.userName like ?");
                list.add("%" + userName + "%");
            }
            if (userRole > 0) {
                sb.append(" and  u.userRole = ?");
                list.add(userRole);
            }

            sb.append(" order by id asc limit  ? ,? ");
            // 1-5
            // 6-10
            // 11-15
            currentPage = (currentPage - 1) * pagesize;
//            System.out.println(currentPage+"daoimp............");
            list.add(currentPage);
            list.add(pagesize);
//            System.out.println(pagesize+"daoimp pagesize");
            Object[] params = list.toArray();
//            for ( Object p: params
//                 ) {
//                System.out.println(p);
//            }

            rs = baseDao.execute(connection, sb.toString(), params, preparedStatement);
            while (rs.next()) {
                User user = new User();
//                System.out.println(rs.getInt("id"));
                user.setId(rs.getInt("id"));
                user.setUserCode(rs.getString("userCode"));
                user.setUserName(rs.getString("userName"));
                user.setGender(rs.getInt("gender"));
                user.setBirthday(rs.getDate("birthday"));
                user.setPhone(rs.getString("phone"));
                user.setUserRole(rs.getInt("userRole"));
                user.setUserRoleName(rs.getString("userRoleName"));

                userList.add(user);
            }
        }
        baseDao.close(connection, preparedStatement, null);


        return userList;
    }

    public boolean useradd(Connection connection, Object [] param) throws SQLException {

        boolean flag = false;
        PreparedStatement preparedStatement = null;

        String sql = "insert into smbms_user (userCode,userName,userPassword,gender,birthday,phone,address,userRole) values (?,?,?,?,?,?,?,?);";
        int row = 0;
//        Object[] param = { "aa", "aaa", "aaa", 1, "1980-06-15", 123123, "gdfgd", 1};
//        数字常量不用加"",字母必须加否则会识别成变脸报错，数字不管加不加都会自动封装好,不加id会自动按顺序标志id
        if (connection != null) {
            row = baseDao.execute2(connection, sql, param, preparedStatement);
            if (row > 0) {
                flag = true;
            }
        }
        baseDao.close(connection, preparedStatement, null);
        return flag;
    }

    public boolean userdelt(Connection connection, int  userid) throws SQLException {
        boolean flag = false;
        PreparedStatement preparedStatement = null;

        String sql = "delete from smbms_user where id = ?;";
        int row = 0;
        Object [] param = {userid};
//        Object[] param = { "aa", "aaa", "aaa", 1, "1980-06-15", 123123, "gdfgd", 1};
//        数字常量不用加"",字母必须加否则会识别成变脸报错，数字不管加不加都会自动封装好,不加id会自动按顺序标志id
        if (connection != null) {
            row = baseDao.execute2(connection, sql, param, preparedStatement);
            if (row > 0) {
                flag = true;
            }
        }
        baseDao.close(connection, preparedStatement, null);
        return flag;
    }

}
