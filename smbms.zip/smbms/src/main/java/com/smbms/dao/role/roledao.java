package com.smbms.dao.role;

import com.smbms.entity.role;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface roledao {
    public List<role> getrolelist(Connection connection) throws SQLException;

}
