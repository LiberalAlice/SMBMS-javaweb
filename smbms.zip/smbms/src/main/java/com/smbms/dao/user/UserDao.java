package com.smbms.dao.user;

import com.smbms.entity.User;
import com.smbms.entity.role;


import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface UserDao {
    public User getLoginUser(Connection connection , String userCode) throws SQLException;

    public boolean pwModify(Connection connection ,int id , String password) throws SQLException;

    //根据用户名或身份查询总人数
    public int getCount(Connection connection ,String userName , int userRole) throws SQLException;

    public List<User> getUserlist(Connection connection , String userName , int userRole, int currentPage, int pagesize) throws SQLException;

    public boolean useradd(Connection connection, Object [] param) throws SQLException;

    public boolean userdelt(Connection connection ,int  userid) throws SQLException;


}
