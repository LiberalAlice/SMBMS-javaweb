package com.smbms.util;

public class contents {
    public static final String UserSession = "userSession";
}
