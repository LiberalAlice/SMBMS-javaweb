package com.smbms.service.role;

import com.smbms.entity.role;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface roleService {
    public List<role> getrolelist() throws SQLException, ClassNotFoundException;
}
