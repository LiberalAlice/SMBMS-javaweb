package com.smbms.service.user;

import com.smbms.dao.baseDao;
import com.smbms.dao.user.UserDao;
import com.smbms.dao.user.UserDaoImp;
import com.smbms.entity.User;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class userServiceImp implements userService{
    private UserDao userDao;

    public userServiceImp() {
        userDao = new UserDaoImp();
    }


    public User login(String userCode, String password) throws SQLException, ClassNotFoundException {
        Connection connection = null;
        User user = null;

        connection = baseDao.getConnection();
        user = userDao.getLoginUser(connection, userCode);

        baseDao.close(connection, null, null);
        return user;
    }

    public boolean pwModify(int id, String password) throws SQLException, ClassNotFoundException {
        boolean flag = false;

        Connection connection = null;
        connection = baseDao.getConnection();

        if (userDao.pwModify(connection, id, password)) {
            flag = true;
        }
        baseDao.close(connection, null, null);
        return flag;
    }

    public int getCount(String userName, int userRole) throws SQLException, ClassNotFoundException {
        int count = 0;
        Connection connection = baseDao.getConnection();
        count  = userDao.getCount(connection, userName, userRole);
        baseDao.close(connection, null, null);
        return count;
    }

    public List<User> getUserlist(String userName, int userRole, int currentPage, int pagesize)  {
        List<User> userList = new ArrayList<User>();
        Connection connection = null;
        try {
            connection = baseDao.getConnection();
            userList = userDao.getUserlist(connection, userName, userRole, currentPage, pagesize);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            baseDao.close(connection, null, null);
        }

        return userList;
    }

    public boolean useradd(Object[] param) throws SQLException, ClassNotFoundException {
        boolean flag = false;

        Connection connection = null;
        connection = baseDao.getConnection();


        if (userDao.useradd(connection,param)) {
            flag = true;
        }
        baseDao.close(connection, null, null);
        return flag;
    }

    public boolean userdele(int userid) throws SQLException, ClassNotFoundException {
        boolean flag = false;

        Connection connection = null;
        connection = baseDao.getConnection();

        if (userDao.userdelt(connection,userid)) {
            flag = true;
        }
        baseDao.close(connection, null, null);
        return flag;
    }

    @Test
    public void test() throws SQLException, ClassNotFoundException {

        Object[] param = { "aa", "aaa", "aaa", 1, "1980-06-15", 123123, "gdfgd", 1};
        useradd(param);
        System.out.println();




    }
}
