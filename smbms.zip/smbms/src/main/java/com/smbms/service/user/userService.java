package com.smbms.service.user;

import com.smbms.entity.User;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface userService {
    public User login(String userCode, String  password) throws SQLException, ClassNotFoundException;
    public boolean pwModify(int  id, String  password) throws SQLException, ClassNotFoundException;
    public int getCount(String userName, int  userRole) throws SQLException, ClassNotFoundException;
    public List<User> getUserlist(String userName , int userRole, int currentPage, int pagesize);
    public boolean useradd(Object [] param) throws SQLException, ClassNotFoundException;
    public boolean userdele(int  userid) throws SQLException, ClassNotFoundException;
}
