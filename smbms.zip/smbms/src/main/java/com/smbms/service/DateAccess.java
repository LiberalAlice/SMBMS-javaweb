package com.smbms.service;


import com.smbms.service.role.roleServiceImp;
import com.smbms.service.user.userServiceImp;

public class DateAccess {
    private static  String AsseblyName = "com.smbms.service";
    private static  String className = "ServiceImp";
    public  static userServiceImp creator() throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        String partName = AsseblyName+"."+"user"+"."+"user"+className;
        return (userServiceImp) Class.forName(partName).newInstance();
    }
    public  static roleServiceImp creator2() throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        String partName = AsseblyName+"."+"role"+"."+"role"+className;
        return (roleServiceImp) Class.forName(partName).newInstance();
    }
}
