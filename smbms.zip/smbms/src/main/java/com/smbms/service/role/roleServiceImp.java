package com.smbms.service.role;

import com.smbms.dao.baseDao;
import com.smbms.dao.role.roledao;
import com.smbms.dao.role.roledaoimp;
import com.smbms.entity.role;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class roleServiceImp implements roleService{
    private roledao roledao = null;

    public roleServiceImp() {
        roledao = new roledaoimp();
    }

    public List<role> getrolelist() throws SQLException, ClassNotFoundException {
        List<role> roleList = new ArrayList<role>();
        Connection connection = null;

        connection = baseDao.getConnection();

        roleList = roledao.getrolelist(connection);

        baseDao.close(connection, null, null);

        return roleList;
    }
    @Test
    public void test(){
        try {
            System.out.println(getrolelist());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
