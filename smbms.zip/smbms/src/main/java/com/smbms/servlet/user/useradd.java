package com.smbms.servlet.user;

import com.alibaba.fastjson.JSONArray;
import com.smbms.service.DateAccess;
import com.smbms.service.user.userServiceImp;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

public class useradd extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("..............doget useradd");

        String id = req.getParameter("uid");
        System.out.println(id);
        int idI = Integer.parseInt(id);
        Map<String, String> map = new HashMap<String, String>();
            userServiceImp userServiceImp = null;
            try {
                userServiceImp = DateAccess.creator();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if(idI <= 0){
                map.put("delResult", "notexist");
            }else{

                try {
                    if(userServiceImp.userdele(idI)){
                        map.put("delResult", "true");
                        System.out.println("删除完成！");
                    }else{
                        map.put("delResult","false");
                        System.out.println("删除失败！");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }

        try{
            System.out.println(map);
            resp.setContentType("application/json");
            PrintWriter writer = resp.getWriter();
            writer.write(JSONArray.toJSONString(map));
        }catch (IOException e){
            e.printStackTrace();
        }

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        System.out.println("get.....");
        //拿到表单的数据，放入
        String usercode = req.getParameter("userCode");
        String userName = req.getParameter("userName");
        String userPassword = req.getParameter("userPassword");
        Integer gender = Integer.valueOf(req.getParameter("gender"));

        java.text.SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String birthday = req.getParameter("birthday");


        String phone = req.getParameter("phone");
        String address = req.getParameter("address");
        Integer userRole = Integer.valueOf(req.getParameter("userRole"));

        userServiceImp userServiceImp = null;
        try {
            Date ParseBirth = formatter.parse(birthday);
            Object[] objects = new Object[]{usercode, userName, userPassword, gender, ParseBirth, phone, address, userRole};
            userServiceImp = DateAccess.creator();
            userServiceImp.useradd(objects);
        } catch (Exception e) {
            e.printStackTrace();
        }
        req.getRequestDispatcher("jsp/frame.jsp").forward(req,resp);

    }
}
