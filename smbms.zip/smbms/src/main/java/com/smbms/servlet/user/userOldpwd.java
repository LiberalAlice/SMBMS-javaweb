package com.smbms.servlet.user;

import com.smbms.entity.User;
import com.smbms.service.user.userServiceImp;
import com.smbms.util.contents;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;

public class userOldpwd extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();

        String oldPassWord = ((User)session.getAttribute(contents.UserSession)).getUserPassword();

        String oldpassword2 = req.getParameter("oldpassword");
        HashMap<String, String> map = new HashMap<String, String>();

        if (oldpassword2 == oldPassWord) {
            map.put("result", "true");
        } else if (oldpassword2 != oldPassWord) {
            map.put("result", "false");
        } else if (oldpassword2 == null) {
            map.put("result", "error");
        } else if (oldPassWord == null) {
            map.put("result", "sessionerror");
        }
        req.setAttribute("oldpassword",map.get("result"));

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }
}
