package com.smbms.servlet.user;

import com.alibaba.fastjson.JSONArray;
import com.smbms.entity.User;
import com.smbms.entity.role;
import com.smbms.service.DateAccess;
import com.smbms.service.role.roleServiceImp;
import com.smbms.service.user.userServiceImp;
import com.smbms.util.contents;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class userDo extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("method");
        System.out.println(method);
        if (method.equals("savepwd") && method != null) {
            this.updatePw(req,resp);
        } else if (method.equals("pwdmodify") && method != null) {
            this.pwModify(req,resp);
        } else if (method.equals("query") && method != null) {
            try {
                this.query(req,resp);
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        if (method.equals("getrolelist") && method != null) {
            try {
                this.getrolelist(req,resp);
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else if (method.equals("ucexist") && method != null) {
            try {
                this.Susercode(req, resp);
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }
    public void updatePw(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();

        int  id = ((User)session.getAttribute(contents.UserSession)).getId();

        String newPassWord = req.getParameter("rnewpassword");
        userServiceImp userServiceImp = null;
        try {
            userServiceImp = DateAccess.creator();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (newPassWord != null) {
            try {
                userServiceImp.pwModify(id,newPassWord);
                req.setAttribute("error","请重新登录");
                req.getRequestDispatcher("/login.jsp").forward(req,resp);
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            req.setAttribute("message","更改失败，请重试");
            resp.sendRedirect("/jsp/pwdmodify.jsp");
        }
    }
    public void pwModify(HttpServletRequest req, HttpServletResponse resp) {
        Object o = req.getSession().getAttribute(contents.UserSession);
        String oldPassWord = ((User)o).getUserPassword();
        System.out.println(oldPassWord+"oldPassWord get from session");

        String oldpassword2 = req.getParameter("oldpassword");
        System.out.println(oldpassword2+"oldpassword2");
        HashMap<String, String> map = new HashMap<String, String>();

        if (oldpassword2.equals(oldPassWord)) {
            map.put("result", "true");
        } else if (oldpassword2 == null) {
            map.put("result", "error");
        } else if (o == null) {
            map.put("result", "sessionerror");
       } else  {
            map.put("result", "false");}


        try {
            resp.setContentType("application/json");
            PrintWriter pw = resp.getWriter();
            pw.write(JSONArray.toJSONString(map));
            pw.flush();
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void query(HttpServletRequest req, HttpServletResponse resp) throws SQLException, ClassNotFoundException {

        String queryUserName = req.getParameter("queryname");
         String temp = req.getParameter("queryUserRole");
         String pageIndex = req.getParameter("pageIndex");

        userServiceImp userServiceImp = null;
        roleServiceImp roleServiceImp = null;
        try {
            roleServiceImp = DateAccess.creator2();
            userServiceImp = DateAccess.creator();
        } catch (Exception e) {
            e.printStackTrace();
        }

        List<role> roleList = null;
        List<User> userList = null;

        int queryUserRole = 0;
        int pagesize = 5;
        int currountpageNo = 1;

        if (queryUserName == null) {
            queryUserName = "";
        }
        if (temp != null && !temp.equals("")) {
            queryUserRole = Integer.parseInt(temp);
        }
        if (pageIndex != null) {
            currountpageNo = Integer.parseInt(pageIndex);
        }

        int totalcount = userServiceImp.getCount(queryUserName, queryUserRole);
        int totalpage = (totalcount/pagesize)+1;

//        PageSupport pageSupport = new PageSupport();
//        pageSupport.setCurrentPageNo(currountpageNo);
//        pageSupport.setPageSize(pagesize);
//        pageSupport.setTotalCount(totalcount);

        if (currountpageNo < 1) {
            currountpageNo = 1;
        } else if (currountpageNo > totalpage) {
            currountpageNo = totalpage;
        }

        userList = userServiceImp.getUserlist(queryUserName, queryUserRole, currountpageNo, pagesize);
        req.setAttribute("userList",userList);
        roleList =roleServiceImp.getrolelist();
        req.setAttribute("roleList",roleList);


        req.setAttribute("currentPageNo",currountpageNo);
        req.setAttribute("totalCount",totalcount);
        req.setAttribute("totalPageCount",totalpage);

        req.setAttribute("queryUserName",queryUserName);
        req.setAttribute("queryUserRole",queryUserRole);

        try {
            req.getRequestDispatcher("jsp/userlist.jsp").forward(req,resp);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private void getrolelist(HttpServletRequest req, HttpServletResponse resp) throws SQLException, ClassNotFoundException, ServletException, IOException {


        System.out.println("getmethod////////////////");
        List<role> roleList = null;
        roleServiceImp roleServiceIMP = null;
        try {
            roleServiceIMP = DateAccess.creator2();

            roleList =roleServiceIMP.getrolelist();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(roleList);
        System.out.println(JSONArray.toJSONString(roleList));

        try {
            resp.setContentType("application/json");
            PrintWriter pw = resp.getWriter();
            pw.write(JSONArray.toJSONString(roleList));
            pw.flush();
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void Susercode(HttpServletRequest req, HttpServletResponse resp) throws SQLException, ClassNotFoundException {
        String userCode1 = req.getParameter("userCode");
        userServiceImp userServiceImp = null;
        Map<String, String> resultMap = new HashMap<String, String>();
        try {
            userServiceImp = DateAccess.creator();
        } catch (Exception e) {
            e.printStackTrace();
        }
        User user = null;
        user = (User) userServiceImp.login(userCode1,null);

        if (user != null) {
            resultMap.put("userCode", "exist");
        }

        try {
            PrintWriter printWriter = resp.getWriter();
            printWriter.write(JSONArray.toJSONString(resultMap));
            printWriter.flush();
            printWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
