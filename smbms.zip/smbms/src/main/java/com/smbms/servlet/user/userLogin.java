package com.smbms.servlet.user;


import com.smbms.entity.User;
import com.smbms.service.DateAccess;
import com.smbms.service.user.userServiceImp;
import com.smbms.util.contents;
import org.junit.jupiter.api.Test;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

public class userLogin extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
         String userCode = req.getParameter("userCode");
         String userPassword = req.getParameter("userPassword");
        User user = null;

//        userServiceImp userServiceImp = new userServiceImp();

        userServiceImp userServiceImp = null;
        try {
            userServiceImp = DateAccess.creator();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        try {
            user = userServiceImp.login(userCode, userPassword);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
//            user = userServiceImp.login("admin", "123");

//        System.out.println(user.getUserPassword().equals(userPassword));
//        System.out.println(user.getUserPassword() == (userPassword));
        if ( user != null && user.getUserPassword().equals(userPassword)) {//
            //数据库中查到对应用户，登录成功

            req.getSession().setAttribute(contents.UserSession,user);
            req.setAttribute(contents.UserSession,user.getUserName());

            req.getRequestDispatcher("jsp/frame.jsp").forward(req,resp);
        }
         else {
            req.setAttribute("用户登录失败", "error");
            System.out.println("login error");
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
        }
    }
    @Test
    public void test(){
        try {
//            userServiceImp userServiceImp = new userServiceImp();
            userServiceImp userServiceImp = DateAccess.creator();
            System.out.println(userServiceImp.login("admin", "123"));
//            userLogin userLogin = new userLogin();
//            userLogin.doGet( new HttpServletRequest(), new HttpServletResponse());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }


    }
}
