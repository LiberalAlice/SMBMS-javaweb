package com.smbms.filter;

import com.smbms.entity.User;
import com.smbms.util.contents;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

public class IllegalLogin implements Filter {
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        User user = (User)(req.getSession().getAttribute(contents.UserSession)) ;
        if (user == null) {
            req.setAttribute("error","请先登录后进入后台管理系统");
            req.getRequestDispatcher("/login.jsp").forward(request,response);
        } else {
            chain.doFilter(request,response);
        }
    }

    public void destroy() {

    }
}
